package com.kh.web.cart.dto;

public class CartChangeDTO {
	private int cartnum;
	private int prodnum;
	private int prodcnt;
	public int getCartnum() {
		return cartnum;
	}
	public void setCartnum(int cartnum) {
		this.cartnum = cartnum;
	}
	public int getProdnum() {
		return prodnum;
	}
	public void setProdnum(int prodnum) {
		this.prodnum = prodnum;
	}
	public int getProdcnt() {
		return prodcnt;
	}
	public void setProdcnt(int prodcnt) {
		this.prodcnt = prodcnt;
	}
	
	
	
}
