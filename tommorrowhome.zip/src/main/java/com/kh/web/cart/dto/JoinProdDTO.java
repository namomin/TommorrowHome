package com.kh.web.cart.dto;

public class JoinProdDTO {
	private String PROD_IMAGE;
	private String PROD_NAME;
	private int PROD_CNT;
	private int PROD_PRICE;
	private int PROD_NUM;
	public String getPROD_IMAGE() {
		return PROD_IMAGE;
	}
	public void setPROD_IMAGE(String pROD_IMAGE) {
		PROD_IMAGE = pROD_IMAGE;
	}
	public String getPROD_NAME() {
		return PROD_NAME;
	}
	public void setPROD_NAME(String pROD_NAME) {
		PROD_NAME = pROD_NAME;
	}
	public int getPROD_CNT() {
		return PROD_CNT;
	}
	public void setPROD_CNT(int pROD_CNT) {
		PROD_CNT = pROD_CNT;
	}
	public int getPROD_PRICE() {
		return PROD_PRICE;
	}
	public void setPROD_PRICE(int pROD_PRICE) {
		PROD_PRICE = pROD_PRICE;
	}
	public int getPROD_NUM() {
		return PROD_NUM;
	}
	public void setPROD_NUM(int pROD_NUM) {
		PROD_NUM = pROD_NUM;
	}
	
	
	
	
	
}
