package com.kh.app.qna;

public class QnaFrontController {

}
