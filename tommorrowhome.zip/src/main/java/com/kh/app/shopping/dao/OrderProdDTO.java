package com.kh.app.shopping.dao;

public class OrderProdDTO {
	private int ORDER_NUM;
	private int PROD_NUM;
	private int PROD_CNT;
	private int PRICE;
	
	
	public int getORDER_NUM() {
		return ORDER_NUM;
	}
	public void setORDER_NUM(int oRDER_NUM) {
		ORDER_NUM = oRDER_NUM;
	}
	public int getPROD_NUM() {
		return PROD_NUM;
	}
	public void setPROD_NUM(int pROD_NUM) {
		PROD_NUM = pROD_NUM;
	}
	public int getPROD_CNT() {
		return PROD_CNT;
	}
	public void setPROD_CNT(int pROD_CNT) {
		PROD_CNT = pROD_CNT;
	}
	public int getPRICE() {
		return PRICE;
	}
	public void setPRICE(int pRICE) {
		PRICE = pRICE;
	}
	
	
	

	
}
